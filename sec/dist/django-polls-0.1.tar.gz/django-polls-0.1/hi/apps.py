from django.apps import AppConfig


class HiConfig(AppConfig):
    name = 'hi'
